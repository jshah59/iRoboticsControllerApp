package com.example.jayam.robot_controller;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.VerticalSeekBar;

import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;

import io.github.controlwear.virtual.joystick.android.JoystickView;

public class MainActivity extends AppCompatActivity {
    public static final int MAX_SERVO_VALUE = 1023;
    public static final int MAX_MOTOR_VALUE = 1023;

    private Map<String, String> parameters = new HashMap<>();
    HttpURLConnection con;
    private String targetURL = "http://192.168.4.1";

    private RequestThread requestThread = new RequestThread();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);

        JoystickView joystick = (JoystickView) findViewById(R.id.joystickView);
        VerticalSeekBar slider1 = (VerticalSeekBar) findViewById(R.id.slider1);
        VerticalSeekBar slider2 = (VerticalSeekBar) findViewById(R.id.slider2);

        // Setup Listeners
        slider1.setOnSeekBarChangeListener(new VerticalSeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar arg0) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar arg0) {
                // Do nothing
            }

            @Override
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                // Send HTTP request here
                int power = (int) Math.floor(MAX_SERVO_VALUE * (progress / 100.0));
                parameters.put("servo1", Integer.toString(power));
                constructAndSendRequest();
            }
        });

        slider2.setOnSeekBarChangeListener(new VerticalSeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar arg0) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar arg0) {
                // Do nothing
            }

            @Override
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                // Send HTTP request here
                int power = (int) Math.floor(MAX_SERVO_VALUE * (progress / 100.0));
                parameters.put("servo2", Integer.toString(power));
                constructAndSendRequest();
            }
        });

        joystick.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {
                int[] motorSpeeds = convertToMotorSpeeds(angle, strength);
                parameters.put("motor1", Integer.toString(motorSpeeds[0]));
                parameters.put("motor2", Integer.toString(motorSpeeds[1]));
                constructAndSendRequest();
            }
        });

        // Setup parameter map
        parameters.put("authKey", "authentication_key");
        parameters.put("motor1", "0");
        parameters.put("motor2", "0");
        parameters.put("servo1", "0");
        parameters.put("servo2", "0");
        parameters.put("validation", "8");
        parameters.put("STOP", "");
        parameters.put("other", "");

        requestThread.start();
    }

    private int calcValidation(int[] speeds) {
        int sum = 0;
        for (int val : speeds) {
            for (char digit : Integer.toString(val).toCharArray()) {
                sum += Integer.parseInt(Character.toString(digit));
            }
        }
        return sum;
    }

    public int[] convertToMotorSpeeds(int angle, int strength) {
        double xControl = strength * Math.cos(Math.toRadians(angle));
        double yControl = strength * Math.sin(Math.toRadians(angle));

        //Invert X
        xControl = xControl * -1;

        //Calc R+L = V
        double vTemp = (100-Math.abs(xControl)) * (yControl/100) + yControl;

        //Calc R-L = W
        double wTemp = (100-Math.abs(yControl)) * (xControl/100) + xControl;

        //Calc R
        double R_Motor = (vTemp + wTemp) / 2;
        double L_Motor = (vTemp - wTemp) / 2;

        //Scale to -1023 to 1023
        R_Motor = (R_Motor * 1023) / 100;
        L_Motor = (L_Motor * 1023) / 100;

        int MotorSpeeds[] = {(int)L_Motor, (int)R_Motor};
        return MotorSpeeds;
    }

    private void constructAndSendRequest() {
        try {
            int[] motorSpeeds = {
                    Integer.parseInt(parameters.get("motor1")),
                    Integer.parseInt(parameters.get("motor2")),
                    Integer.parseInt(parameters.get("servo1")),
                    Integer.parseInt(parameters.get("servo2"))
            };
            parameters.put("validation", Integer.toString(calcValidation(motorSpeeds)));
            requestThread.addRequest(ParameterStringBuilder.getParameterString(parameters));
        } catch (Exception e) {
            System.out.println("Something went wrong adding the request.");
            System.out.println("Message: " + e.getMessage());
        }
    }
}
