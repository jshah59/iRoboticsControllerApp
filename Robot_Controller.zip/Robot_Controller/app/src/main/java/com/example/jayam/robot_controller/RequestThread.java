package com.example.jayam.robot_controller;

import java.io.DataOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TransferQueue;

public class RequestThread extends Thread {
    public Queue<String> requests;
    private String prevRequest = "";

    public RequestThread() {
        this.requests = new LinkedList<>();
    }

    public boolean addRequest(String reqStr) {
        return this.requests.add(reqStr);
    }

    public void run() {
        while (true) {
            if (this.requests.isEmpty()) {
                String targetURL = "http://192.168.4.1/";
                if (!prevRequest.equals("")) {
                    targetURL += "?";
                    targetURL += this.prevRequest;
                } else {
                    continue;
                }
                try {
                    URL botURL = new URL(targetURL);
                    HttpURLConnection con = (HttpURLConnection) botURL.openConnection();
                    System.out.println("Response: " + con.getResponseMessage());
                    con.disconnect();
                } catch (Exception e) {
                    System.out.println("Failed!");
                    System.out.println(e.getMessage());
                }
            } else {
                try {
                    this.prevRequest = this.requests.peek();
                    String targetURL = "http://192.168.4.1/?" + this.requests.poll();
                    URL botURL = new URL(targetURL);
                    HttpURLConnection con = (HttpURLConnection) botURL.openConnection();
                    System.out.println("Response: " + con.getResponseMessage());
                    con.disconnect();
                } catch (Exception e) {
                    System.out.println("Failed!");
                    System.out.println(e.getMessage());
                }
            }
        }
    }



}
